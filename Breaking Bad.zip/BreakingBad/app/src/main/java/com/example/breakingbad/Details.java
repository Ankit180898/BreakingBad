package com.example.breakingbad;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class Details extends AppCompatActivity {
    TextView title,episode,season,airdate,characters;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
        title=findViewById(R.id.title1);
        episode=findViewById(R.id.episode1);
        season=findViewById(R.id.season1);
        airdate=findViewById(R.id.airDate);
        characters=findViewById(R.id.tvCharacters);

        // Recieve data
        Intent intent = getIntent();
        String Title = intent.getExtras().getString("title");
        String Episode = intent.getExtras().getString("episode");
        String Season=intent.getExtras().getString("season");
        String Air_date=intent.getExtras().getString("air_date");



        // Setting values

        title.setText(Title);
        episode.setText(Episode);
        season.setText(Season);
        airdate.setText(Air_date);

    }
}