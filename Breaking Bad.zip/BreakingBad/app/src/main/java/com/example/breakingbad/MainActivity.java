package com.example.breakingbad;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;

import com.example.breakingbad.Adapter.ModelAdapter;
import com.example.breakingbad.api.ApiInterface;
import com.example.breakingbad.api.RetrofitInstance;
import com.example.breakingbad.model.Model;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private RecyclerView rv;
    private List<Model> modelList;
    private ModelAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        modelList=new ArrayList<>();

        //recyclerView
        rv=findViewById(R.id.recyclerView);
        rv.setHasFixedSize(true);
        rv.setLayoutManager(new LinearLayoutManager(this));
        adapter=new ModelAdapter(getApplicationContext(),modelList);
        rv.setAdapter(adapter);

        //retrofit
        ApiInterface apiService = RetrofitInstance.getClient().create(ApiInterface.class);
        Call<List<Model>> call = apiService.getData();
        call.enqueue(new Callback<List<Model>>() {

            @Override
            public void onResponse(Call<List<Model>> call, Response<List<Model>> response) {
                modelList = response.body();
                Log.d("TAG","Response = "+modelList);
                adapter.setDataList(modelList);
            }

            @Override
            public void onFailure(Call<List<Model>> call, Throwable t) {
                Log.d("TAG","Response = "+t.toString());
            }
        });



    }
}

